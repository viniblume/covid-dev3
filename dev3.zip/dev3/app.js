const express=require('express');
const bodyParser=require('body-parser');
const mysql =require('mysql');
const { engine } =require('express-handlebars');
const { response } = require('express');
const app=express();
const urlencodeParser=bodyParser.urlencoded({extended:false});
//added conection with DB
/*
const sql=mysql.createConnection({
  host:'localhost',
  port:5433,
  user:'postgres',
  password:'admin'
});
sql.query("use postgresql");
*/
app.engine("handlebars", engine());
app.set('view engine','handlebars');
app.set('views','./views');

//Start server
app.listen(3000,function(req,res){
  console.log('Servidor está rodando!');
});

app.get("/",function(req,res){
  res.render('index');
});

//Testing in DB
const {TestDB} = require('TestDB');
const mySQLString='mysql://b898e9e30601b5:aba75588@us-cdbr-east-05.cleardb.net/heroku_1607533082d179f?reconnect=true';
const database = new TestDB(mySQLString);

app.use(bodyParser.json());
app.post('/vacina/cadastrar', async (req, res) => {
  await database.execute(   
    INSERT INTO Vacinas (
      ID, 
      Descricao_Material
    ) VALUES, (
      @ID,
      @Descricao_Material
    )
  ),{
      ID: req.body.lote;
      Descricao_Material: req.body.marca,
  });
 
  res.end('Vacina adicionada.');

});
app.use('/css',express.static('css'));
app.use('/js',express.static('js'));
app.use('/img',express.static('img'));